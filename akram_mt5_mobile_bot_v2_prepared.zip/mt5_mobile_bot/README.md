# Akram MT5 Mobile Bot — V2

A demo-first Android control dashboard around the supplied MT5 Python strategy.

## Included
- Android dashboard
- Start/stop/emergency-stop controls
- Account/equity/open-position status
- Signal endpoint using the supplied EMA + RSI + ATR + 20-bar breakout logic
- Risk/settings API
- Paper-event history using SQLite
- 15-second Android polling
- Backend health endpoint

## Important architecture
The Android app is a controller/monitor. The MT5 Python engine must run on a machine that supports the MetaTrader 5 Python package (normally Windows desktop/VPS). The phone itself is not the MT5 execution host.

## Demo first
Keep `DRY_RUN=true`. The supplied strategy explicitly says it is an educational/engineering template and recommends a DEMO account first. It also warns that no strategy guarantees precision or profits.

## Backend
```bash
cd backend
python -m venv .venv
# Windows: .venv\\Scripts\\activate
pip install -r requirements.txt
set API_TOKEN=replace-with-a-long-random-token
uvicorn app.main:app --host 0.0.0.0 --port 8000
```

Configure the Android `baseUrl` and `token` in `MainActivity.kt` before building.

## Android build
Open the `android` folder in Android Studio and build an APK. This package is source code; an APK is not included because this environment does not contain the Android SDK/Gradle build toolchain.

## Production TODO
Use HTTPS, store the token in Android Keystore/server environment, persistent daily-loss state, authenticated user accounts, audit logging, reconnect handling, broker-specific order filling, and a tested emergency shutdown path. Never embed broker passwords in the APK.
