plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }

android { namespace = "com.akram.mt5bot"; compileSdk = 35
    defaultConfig { applicationId = "com.akram.mt5bot"; minSdk = 26; targetSdk = 35; versionCode = 1; versionName = "1.0" }
}
