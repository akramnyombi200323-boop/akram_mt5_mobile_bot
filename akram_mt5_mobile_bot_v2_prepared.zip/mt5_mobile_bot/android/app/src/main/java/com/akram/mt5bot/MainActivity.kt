package com.akram.mt5bot

import android.app.Activity
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.widget.*
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import kotlin.concurrent.thread

class MainActivity : Activity() {
    private val baseUrl = "http://192.168.1.100:8000"
    private val token = "CHANGE_ME_API_TOKEN"
    private val handler = Handler(Looper.getMainLooper())
    private var lastSignals = ""
    private lateinit var status: TextView
    private lateinit var account: TextView
    private lateinit var signals: TextView
    private lateinit var history: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        status=findViewById(R.id.status); account=findViewById(R.id.account); signals=findViewById(R.id.signals); history=findViewById(R.id.history)
        createChannel()
        findViewById<Button>(R.id.start).setOnClickListener { post("/bot/start") }
        findViewById<Button>(R.id.stop).setOnClickListener { post("/bot/stop") }
        findViewById<Button>(R.id.emergency).setOnClickListener { post("/bot/emergency-stop") }
        findViewById<Button>(R.id.refresh).setOnClickListener { refreshAll() }
        refreshAll()
        handler.post(object: Runnable { override fun run(){ refreshAll(); handler.postDelayed(this,15000) } })
    }

    private fun createChannel(){
        val nm=getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(NotificationChannel("signals","Trading signals",NotificationManager.IMPORTANCE_DEFAULT))
    }

    private fun request(path:String, method:String="GET"):String?=try{
        val c=URL(baseUrl+path).openConnection() as HttpURLConnection
        c.requestMethod=method; c.setRequestProperty("X-API-Token",token); c.connectTimeout=5000; c.readTimeout=5000
        c.inputStream.bufferedReader().use{it.readText()}
    }catch(e:Exception){null}

    private fun post(path:String)=thread{ request(path,"POST"); refreshAll() }

    private fun refreshAll(){ thread{
        val s=request("/status"); val sig=request("/signals"); val hist=request("/history")
        runOnUiThread{
            if(s==null){status.text="🔴 OFFLINE"; account.text="Unable to reach backend"; return@runOnUiThread}
            val j=JSONObject(s)
            status.text=if(j.optBoolean("running"))"🟢 BOT RUNNING" else "⚪ BOT STOPPED"
            account.text="Balance: ${j.opt("balance")}\nEquity: ${j.opt("equity")}\nFloating P/L: ${j.opt("profit")}\nOpen positions: ${j.optInt("open_positions")}\nMT5: ${if(j.optBoolean("mt5_connected"))"CONNECTED" else "OFFLINE"}\nMode: ${if(j.optBoolean("dry_run"))"DRY RUN" else "LIVE"}"
            signals.text=formatSignals(sig)
            history.text=formatHistory(hist)
        }
    }}

    private fun formatSignals(raw:String?):String{
        if(raw==null) return "Signals unavailable"
        return try{
            val a=JSONArray(raw); val sb=StringBuilder("SIGNALS\n\n")
            for(i in 0 until a.length()){
                val j=a.getJSONObject(i); sb.append(j.getString("symbol")).append("  ").append(j.getString("signal"))
                    .append("\nRSI ").append(String.format("%.1f",j.getDouble("rsi"))).append(" | ATR ").append(String.format("%.5f",j.getDouble("atr"))).append("\n\n")
            }; sb.toString()
        }catch(e:Exception){"Signals unavailable"}
    }

    private fun formatHistory(raw:String?):String{
        if(raw==null) return "History unavailable"
        return try{ val a=JSONArray(raw); val sb=StringBuilder("RECENT PAPER EVENTS\n\n"); for(i in 0 until minOf(a.length(),10)){val j=a.getJSONObject(i); sb.append(j.optString("symbol")).append(" ").append(j.optString("side")).append(" ").append(j.optString("kind")).append("\n")}; sb.toString() }catch(e:Exception){"History unavailable"}
    }
}
